import { useEffect, useState } from 'react';
import axios from './axios';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';

function App() {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    const res = await axios.get('/');
    setTasks(res.data);
  };

  const addTask = async (title) => {
    const res = await axios.post('/', { title });
    setTasks([...tasks, res.data]);
  };

  const updateTask = async (id, updatedTask) => {
    const res = await axios.put(`/${id}`, updatedTask);
    setTasks(tasks.map(t => t._id === id ? res.data : t));
  };

  const deleteTask = async (id) => {
    await axios.delete(`/${id}`);
    setTasks(tasks.filter(t => t._id !== id));
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <div className="App">
      <h1>📝 To-Do List</h1>
      <TaskForm onAdd={addTask} />
      <TaskList tasks={tasks} onUpdate={updateTask} onDelete={deleteTask} />
    </div>
  );
}

export default App;
