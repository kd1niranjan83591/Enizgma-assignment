import { useState } from 'react';

function TaskForm({ onAdd }) {
  const [title, setTitle] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    onAdd(title);
    setTitle('');
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        marginTop: '20px' 
      }}
    >
      <input
        placeholder="Add a task..."
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        style={{
          padding: '10px',
          fontSize: '16px',
          width: '300px'
        }}
      />
      <button 
        type="submit" 
        style={{ 
          marginLeft: '10px', 
          padding: '10px' 
        }}
      >
        Add
      </button>
    </form>
  );
}

export default TaskForm;
