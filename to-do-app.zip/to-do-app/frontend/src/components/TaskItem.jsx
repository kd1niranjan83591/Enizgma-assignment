function TaskItem({ task, onUpdate, onDelete }) {
    const toggleComplete = () => {
      onUpdate(task._id, { ...task, completed: !task.completed });
    };
  
    return (
      <li>
        <span
          onClick={toggleComplete}
          style={{ textDecoration: task.completed ? 'line-through' : 'none', cursor: 'pointer' }}
        >
          {task.title}
        </span>
        <button onClick={() => onDelete(task._id)}>❌</button>
      </li>
    );
  }
  
  export default TaskItem;
  