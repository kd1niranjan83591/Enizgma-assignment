function TaskList({ tasks, onUpdate, onDelete }) {
    return (
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {tasks.map((task) => (
          <li key={task._id} style={{ marginBottom: '10px' }}>
            {task.title}
            <button
              onClick={() => {
                const newTitle = prompt('Edit task:', task.title);
                if (newTitle && newTitle.trim()) {
                  onUpdate(task._id, { title: newTitle });
                }
              }}
              style={{ marginLeft: '10px' }}
            >
              Update
            </button>
            <button
              onClick={() => onDelete(task._id)}
              style={{ marginLeft: '5px' }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    );
  }
  
  export default TaskList;
  